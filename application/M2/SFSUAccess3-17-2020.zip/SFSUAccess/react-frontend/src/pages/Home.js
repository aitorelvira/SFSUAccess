import React, { useState, useEffect } from 'react';
import Search from '../components/Search';
function Home() {
    return (
        <div>
            <h1>SFSU Access</h1>
            <p>CSC 648 Section 01, Spring 2020, Team 02</p>
            <Search/>
        </div>
    );
}

export default Home;