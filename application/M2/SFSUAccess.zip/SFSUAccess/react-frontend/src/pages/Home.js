import React from 'react';

const home = () => {
    return (
       <div>
          <h1>Home</h1>
           <p>Home page body content</p>
       </div>
    );
}

export default home;